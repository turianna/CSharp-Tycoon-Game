﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpongeBobTycoon.Model
{
    public class Stop
    {
        public Product product { get; set; }
        public int X;
        public int Y;

        public Stop(Product product, int x, int y) 
        {
            this.product = product;
            this.X = x;
            this.Y = y;

        }
    }
}
