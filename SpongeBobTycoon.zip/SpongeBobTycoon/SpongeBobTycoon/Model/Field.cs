﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpongeBobTycoon.Model
{
    public class Field
    {
        public int X ; public int Y;

        public FieldType fieldType;

        public Field(int x, int y, FieldType ft)
        {
            this.X = x;
            this.Y = y;
            this.fieldType = ft;
        }
    }
}
