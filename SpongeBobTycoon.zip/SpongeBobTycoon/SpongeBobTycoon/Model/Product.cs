﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpongeBobTycoon.Model
{
    public enum Product
    {
        STEEL,
        NET,

        SPATULA,
        JELLYFISH,
        CITIZEN,
        EMPTY
    }
}
