﻿using SpongeBobTycoon.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpongeBobTycoon.Persistence
{
    public class DataAccess
    {
        public async Task<GameData> Load(String path) { }
        public async Task Save(String path, GameModel model) { }
    }
}
